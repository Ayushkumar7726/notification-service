package com.example.notification.service;

import com.example.notification.config.RabbitMQConfig;
import com.example.notification.model.Notification;
import com.example.notification.model.User;
import com.example.notification.repository.NotificationRepository;
import com.example.notification.repository.UserRepository;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private NotificationRepository notifRepo;

    @Autowired
    private RabbitTemplate rabbitTemplate;  // RabbitMQ template

    public void sendNotification(Long userId, String type, String content) {
        Optional<User> userOptional = userRepo.findById(userId);
        if (userOptional.isEmpty()) {
            throw new RuntimeException("User not found with ID: " + userId);
        }
        User user = userOptional.get();

        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setType(type);
        notification.setContent(content);
        notification.setStatus("pending");
        notifRepo.save(notification);

        try {
            rabbitTemplate.convertAndSend(
                    RabbitMQConfig.EXCHANGE_NAME,
                    RabbitMQConfig.MAIN_ROUTING_KEY,  // Updated here
                    notification
            );
            notification.setStatus("queued");
        } catch (Exception e) {
            e.printStackTrace();
            notification.setStatus("failed");
        }

        notifRepo.save(notification);
    }

    // Get notifications by user ID
    public List<Notification> getNotificationsByUserId(Long userId) {
        return notifRepo.findByUserId(userId);
    }
}
