package com.example.notification.model;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name="notifications")
@Data
public class Notification implements Serializable {
    @Id
    @GeneratedValue
    private Long id;
    private Long userId;
    private String type; // email, sms, inapp
    private String content;
    private String status; // pending, sent, failed
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() {
        return id;
    }
    public String getType() {
        return type;
    }
    public String getContent() {
        return content;
    }
    public Long getUserId() {
        return userId;
    }
    public String getStatus() {
        return status;
    }
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
