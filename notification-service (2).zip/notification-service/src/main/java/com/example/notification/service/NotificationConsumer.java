package com.example.notification.service;

import com.example.notification.config.RabbitMQConfig;
import com.example.notification.model.Notification;
import com.example.notification.repository.NotificationRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class NotificationConsumer {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private JavaMailSender mailSender;

    @RabbitListener(queues = RabbitMQConfig.MAIN_QUEUE)
    public void receiveNotification(Notification notification) {
        System.out.println("Received notification from queue: " + notification.getContent());

        try {
            String type = notification.getType();
            if (type == null) {
                throw new IllegalArgumentException("Notification type is null");
            }

            switch (type.toLowerCase(Locale.ROOT)) {
                case "email":
                    sendEmail(notification);
                    break;
                case "sms":
                    sendSms(notification);
                    break;
                case "inapp":
                    // Add in-app notification logic here if needed
                    break;
                default:
                    // Log and mark as failed, but do NOT rethrow to avoid infinite retries
                    System.err.println("Unsupported notification type: " + type);
                    notification.setStatus("failed");
                    notification.setContent(notification.getContent() + " (Unsupported type: " + type + ")");
                    notificationRepository.save(notification);
                    return;
            }

            notification.setStatus("sent");
        } catch (Exception e) {
            e.printStackTrace();
            notification.setStatus("failed");

            // Optionally rethrow if you want DLQ retry behavior
            // throw new RuntimeException(e);
        }

        notificationRepository.save(notification);
    }

    private void sendEmail(Notification notification) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(getUserEmail(notification.getUserId())); // Implement your email fetching logic
        message.setSubject("Notification");
        message.setText(notification.getContent());
        mailSender.send(message);
    }

    private void sendSms(Notification notification) {
        // Simulate SMS sending logic
        System.out.println("Simulated SMS to user " + notification.getUserId() + ": " + notification.getContent());
    }

    private String getUserEmail(Long userId) {
        // Placeholder: replace with your user email lookup
        return "user@example.com";
    }
}
