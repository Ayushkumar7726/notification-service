package com.example.notification.model;

public class NotificationMessage {
    private Long userId;
    private String type;
    private String content;

    public NotificationMessage() {}

    public NotificationMessage(Long userId, String type, String content) {
        this.userId = userId;
        this.type = type;
        this.content = content;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
